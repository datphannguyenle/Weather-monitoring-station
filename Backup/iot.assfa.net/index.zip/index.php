<!DOCTYPE html>
<!-- Designined by CodingLab | www.youtube.com/codinglabyt -->
<html lang="en" dir="ltr">

<head>
  <meta charset="UTF-8">
  <title>SkyLab</title>


  <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.5.0/Chart.min.js"></script>
  <script src="https://code.highcharts.com/highcharts.js"></script>
  <script src="https://code.highcharts.com/modules/exporting.js"></script>
  <script src="https://code.highcharts.com/modules/export-data.js"></script>
  <script src="https://code.highcharts.com/modules/accessibility.js"></script>

  <!-- <link rel="stylesheet" href="css/jquery.mobile-1.4.2.min.css" /> -->
  <script src="js/jquery.js"></script>
  <script src="js/jquery.mobile-1.4.2.min.js"></script>

  <!-- Fontawesome CDN Link -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <link rel="stylesheet" href="css/style.css">

  <!-- <meta http-equiv="refresh" content="5"> -->
</head>

<body>
  <!-- Move to up button -->
  <div class="scroll-button">
    <a href="#home"><i class="fas fa-arrow-up"></i></a>
  </div>
  <!-- navgaition menu -->
  <nav>
    <div class="navbar">
      <div class="logo"><a href="#">SkyLab.</a></div>
      <ul class="menu">
        <li><a href="#home">Home</a></li>
        <li><a href="#about">About</a></li>
        <div class="cancel-btn">
          <i class="fas fa-times"></i>
        </div>
      </ul>
    </div>
    <div class="menu-btn">
      <i class="fas fa-bars"></i>
    </div>
  </nav>

  <!-- Home Section Start -->
  <section class="home" id="home">
    <div class="home-content">
      <div class="text">
        <div class="text-one">Hello,</div>
        <div class="text-two">We're SkyLab</div>
        <div class="text-three">Meteorological Station</div>
        <div class="text-four">From HCMUTE</div>
      </div>
      <div class="button">
        <button onclick="window.location.href='main.php'">Start</button>
      </div>
    </div>
  </section>

  <!-- About Section Start -->
  <section class="about" id="about">
    <div class="content">
      <div class="title"><span>About Team</span></div>
      <div class="about-details">
        <div class="left">
          <img src="images/dat.jpg" alt="">
        </div>
        <div class="right">
          <div class="topic">Le Phan Nguyen Dat</div>
          <p>Ho Chi Minh City University of Technology and Education
            <br>Major Field of Study: Embedded Systems and Internet of Things
          </p>
          <div class="button">
            <button>Contact</button>
          </div>
        </div>
      </div>
      <div class="about-details">
        <div class="left">
          <img src="images/tam.jpg" alt="">
        </div>

        <div class="right">
          <div class="topic">Nguyen Hoai Tam</div>
          <p>Ho Chi Minh City University of Technology and Education
            <br>Major Field of Study: Embedded Systems and Internet of Things
          </p>
          <div class="button">
            <button>Contact</button>
          </div>
        </div>
      </div>

      <div class="about-details">
        <div class="left">
          <img src="images/uy.jpg" alt="">
        </div>
        <div class="right">
          <div class="topic">Ly Tran Quoc Uy</div>
          <p>Ho Chi Minh City University of Technology and Education
            <br>Major Field of Study: Embedded Systems and Internet of Things
          </p>
          <div class="button">
            <button>Contact</button>
          </div>
        </div>
      </div>
    </div>
  </section>

  <script src="js/script.js"></script>
</body>

</html>